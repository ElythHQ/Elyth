__version__ = "0.0.0.1" 
__author__ = "Karl Benjamin R. Bughaw / ElythHQ"
__license__ = "MIT" 

from .bot import ElythBot
__all__ = ['ElythBot', '__version__', '__author__', '__license__']
print(f"Elyth Package v{__version__} (Simplicity Model) loaded.")